-- 1.Does any table have missing values or duplicates? If yes how would you handle it ?

use chinook;
-- checking if, there are any null values in any of the columns. 
select * from employee 
where last_name IS NULL 
or first_name IS NULL 
or title IS NULL 
OR reports_to IS NULL 
or birthdate IS NULL 
or hire_date IS NULL
OR  address IS NULL OR  city IS NULL
OR state IS NULL
or country IS NULL
or postal_code IS NULL
or phone IS NULL 
or fax IS NULL
or email IS NULL;
-- Handling NULL values
select employee_id,COALESCE(reports_to,0)as reports_to from employee;
-- Handling null values for customer table
select customer_id,coalesce(company,'N/A')as company,coalesce(state,'N/A')as state,coalesce(country,'N/A')as country,coalesce(postal_code,'N/A')
as postal_code,coalesce(phone,'N/A')as phone from customer;

-- 2. Find the top-selling tracks and top artist in the USA and identify their most famous genres.

-- Calculating each track's total sales:
with track_sales as(
 select il.track_id,sum(il.quantity)as total_sales from invoice_line il
 join invoice i on i.invoice_id=il.invoice_id
 where i.billing_country='USA'
 group by il.track_id

 ),
-- Calculating the top_selling track and top artist in USA
top_track_artist as(
 select t.name as track_name,ts.track_id,ts.total_sales,a.artist_id,ar.name as artist_name from track_sales ts
 join track t on t.track_id=ts.track_id
 join album a on a.album_id=t.album_id
 join artist ar on ar.artist_id=a.artist_id
 order by total_sales desc
 limit 1
)
-- Most famous genre of the top selling track
 select tsa.track_name,tsa.artist_name,g.name as genre_name from top_track_artist tsa
 join track t on t.track_id=tsa.track_id
 join genre g on g.genre_id=t.genre_id;
 
--  3.	What is the customer demographic breakdown (age, gender, location) of Chinook's customer base?

-- customer demographic breakdown by country
SELECT COALESCE(country,'N/A')as country, COUNT(customer_id) AS NumberOfCustomers
FROM customer
GROUP BY country
ORDER BY NumberOfCustomers DESC;
-- customer demographic breakdown by state
SELECT COALESCE(state,'N/A') as state, COUNT(customer_id) AS NumberOfCustomers
FROM customer
GROUP BY state
ORDER BY NumberOfCustomers DESC; 
-- customer demographic breakdown by city
SELECT COALESCE(city,'N/A') as city, COUNT(customer_id) AS NumberOfCustomers
FROM customer
GROUP BY city
ORDER BY NumberOfCustomers DESC;

 -- 4. Calculate the total revenue and number of invoices for each country, state, and city:
 
--  Total revenue and number of invoices for each country:
 select c.country,sum(il.unit_price*il.quantity)as total_revenue,count(il.invoice_id)as n_invoices
 from invoice i
 JOIN invoice_line il on il.invoice_id=i.invoice_id
 JOIN customer c on c.customer_id=i.customer_id
 group by c.country
 order by total_revenue desc,n_invoices desc;
 --  Total revenue and number of invoices for each state:
 select coalesce(c.state,'N/A')as state,sum(il.unit_price*il.quantity)as total_revenue,count(il.invoice_id)as n_invoices
 from invoice i
 JOIN invoice_line il on il.invoice_id=i.invoice_id
 JOIN customer c on c.customer_id=i.customer_id
 group by state
 order by total_revenue desc,n_invoices desc;
 --  Total revenue and number of invoices for each city:
 select coalesce(c.city,'N/A')as city,sum(il.unit_price*il.quantity)as total_revenue,count(il.invoice_id)as n_invoices
 from invoice i
 JOIN invoice_line il on il.invoice_id=i.invoice_id
 JOIN customer c on c.customer_id=i.customer_id
 group by city
 order by total_revenue desc,n_invoices desc;
 
-- 5. Find the top 5 customers by total revenue in each country
select i.customer_id,concat(c.first_name," ",c.last_name) as customer_name,
c.country,sum(il.unit_price*il.quantity)as total_revenue from invoice i
join customer c on c.customer_id=i.customer_id
join invoice_line il on il.invoice_id=i.invoice_id
group by customer_id,c.country
order by total_revenue desc
 limit 5;
 
--  6.Identify the top-selling track for each customer
use chinook
WITH Total_Quantity_Customer AS (
    select c.customer_id, CONCAT(c.first_name, ' ', c.last_name) AS customer_name, SUM(il.quantity) AS total_sales
    from customer c
    INNER JOIN invoice i ON c.customer_id = i.customer_id
    INNER JOIN invoice_line il ON i.invoice_id = il.invoice_id
    INNER JOIN track t ON t.track_id = il.track_id
    group by c.customer_id, customer_name
),
track_ranking AS (
    select T.customer_id, T.customer_name, T.total_sales, t.track_id, t.name AS track_name,
	ROW_NUMBER() OVER (PARTITION BY T.customer_id ORDER BY T.total_sales DESC) AS rnk
    from Total_Quantity_Customer T
    INNER JOIN invoice i ON T.customer_id = i.customer_id
    INNER JOIN invoice_line il ON i.invoice_id = il.invoice_id
    INNER JOIN track t ON t.track_id = il.track_id
)
select customer_id, customer_name, track_id, track_name, total_sales
from track_ranking
where rnk = 1
order by customer_id;


-- 7.Are there any patterns or trends in customer purchasing behavior (e.g., frequency of purchases, 
-- preferred payment methods, average order value)? 

-- --Frequency of Purchases -- --
SELECT c.customer_id,CONCAT(c.first_name, ' ', c.last_name) as customers,YEAR(i.invoice_date) AS year,COUNT(i.invoice_id) AS purchase_count
FROM customer c
INNER JOIN invoice i ON c.customer_id = i.customer_id
GROUP BY c.customer_id, customers, YEAR(i.invoice_date)
ORDER BY c.customer_id, customers, YEAR(i.invoice_date);

-- -- Calculate the average order value for each customer -- --
select customer_id,customer_name,ROUND(AVG(total_order_value), 2)as avg_order_value
from(
SELECT c.customer_id, CONCAT(c.first_name, ' ', c.last_name) as customer_name, SUM(i.total)AS total_order_value
FROM customer c 
INNER JOIN invoice i ON c.customer_id = i.customer_id
GROUP BY c.customer_id, customer_name
)total
GROUP BY customer_id,customer_name
ORDER BY avg_order_value desc;

-- Identifying the trend on customer purchasing behaviour
SELECT month,AVG(total_value) AS average_order_value, number_of_invoices from (
SELECT DATE_FORMAT(i.invoice_date, '%Y-%m') AS month, SUM(i.total) AS total_value, COUNT(i.invoice_id) AS number_of_invoices
FROM invoice i
GROUP BY DATE_FORMAT(i.invoice_date, '%Y-%m')
)t
GROUP BY month
ORDER BY month;

-- 8.What is the customer churn rate?
WITH last_invoice_date AS (
    select MAX(invoice_date) AS last_invoice_date
    from invoice
),
TimeInterval AS (
    select  DATE_SUB(last_invoice_date, INTERVAL 1 YEAR) AS interval_time
    from last_invoice_date
),
ChurnedCustomers AS (
    select c.customer_id, COALESCE(c.first_name || ' ' || c.last_name) AS customers, MAX(i.invoice_date) AS last_purchase_date
    from customer c
    LEFT JOIN invoice i ON c.customer_id = i.customer_id
    group by c.customer_id, customers
    having MAX(i.invoice_date) IS NULL OR MAX(i.invoice_date) < (SELECT interval_time from TimeInterval)
)
-- Calculate the churn rate
select (SELECT COUNT(*) FROM ChurnedCustomers) / (SELECT COUNT(*) FROM customer) * 100 AS churn_rate from ChurnedCustomers;

-- 9.Calculate the percentage of total sales contributed by each genre in the USA and identify the best-selling genres and artists.
with total_sales_genre as(
select g.name as genre_name,sum(il.quantity)as total_sales
from invoice_line il
join track t on t.track_id=il.track_id
join genre g on g.genre_id=t.genre_id
join invoice i on i.invoice_id=il.invoice_id
join customer c on c.customer_id=i.customer_id
 where c.country='USA'
group by g.name
),
overall_sales as(
select sum(il.quantity)as total_sales from invoice_line il
join invoice i on i.invoice_id=il.invoice_id
join customer c on c.customer_id=i.customer_id
where c.country='USA'
 )
select t.genre_name,(t.total_sales*100/s.total_sales)as percentage_genre from total_sales_genre t,overall_sales s
order by t.total_sales desc;
-- top artists in USA
 select a.name as artist,sum(il.quantity)as total_sales
  from invoice_line il
  join track t on t.track_id=il.track_id
  join album b on b.album_id=t.album_id
  join artist a on a.artist_id=b.artist_id
  join invoice i on i.invoice_id=il.invoice_id
  join customer c on c.customer_id=i.customer_id
  where c.country='USA'
  group by a.name
  order by total_sales desc;

--  10. Find customers who have purchased tracks from at least 3 different genres
select c.customer_id,c.first_name,c.last_name,count(distinct g.genre_id)as different_genres from customer c 
join invoice i on i.customer_id=c.customer_id
join invoice_line il on il.invoice_id=i.invoice_id
join track t on t.track_id=il.track_id
join genre g on g.genre_id=t.genre_id
group by c.customer_id
having count(distinct g.genre_id)>=3;

-- 11.Rank genres based on their sales performance in the USA
select g.name as genre_name, sum(il.quantity)as total_sales, RANK() OVER(order by sum(il.quantity)desc)as genre_rank
from invoice_line il
join track t on t.track_id=il.track_id
join genre g on g.genre_id=t.genre_id
join invoice i on i.invoice_id=il.invoice_id
join customer c on c.customer_id=i.customer_id
where c.country='USA'
group by g.name;

-- 12.Identify customers who have not made a purchase in the last 3 months
select c.customer_id,c.first_name,c.last_name from customer c
left join invoice i on i.customer_id=c.customer_id
where invoice_date IS NULL OR invoice_date< DATE_SUB(CURRENT_DATE, INTERVAL 3 MONTH)
group by c.customer_id,c.first_name,c.last_name;

                                        -- subjective :
-- 1.	Recommend the three albums from 
-- the new record label that should be prioritised for advertising and promotion in the USA based on genre sales analysis.

SELECT g.genre_id,g.name as genre_name,al.album_id,al.title as New_Record_Label,SUM(il.quantity)as total_sales,
DENSE_RANK() OVER(ORDER BY SUM(il.quantity) DESC) AS Sale_Rank
FROM genre g
JOIN track t on t.genre_id=g.genre_id
JOIN invoice_line il on t.track_id=il.track_id
JOIN invoice i on i.invoice_id=il.invoice_id
JOIN customer c on c.customer_id=i.customer_id
JOIN album al on al.album_id=t.album_id
WHERE c.country='USA'
GROUP BY g.genre_id,g.name,al.album_id,al.title
ORDER BY total_sales DESC;

-- 2.	Determine the top-selling genres in countries other than the USA and identify any commonalities or differences.

select c.country,g.name as genre_name,sum(il.quantity)as total_sales from genre g
join track t on t.genre_id=g.genre_id
join invoice_line il on il.track_id=t.track_id
join invoice i on i. invoice_id=il.invoice_id
join customer c on c.customer_id=i.customer_id
where c.country!='USA'
group by g.genre_id,g.name,c.country
order by total_sales desc;

-- 3.	Customer Purchasing Behavior Analysis: How do the purchasing habits (frequency, basket size, spending amount) 
-- of long-term customers differ from those of new customers?
--  What insights can these patterns provide about customer loyalty and retention strategies?

--  Define observation periods
WITH Purchase_status AS (
select c.customer_id, COUNT(i.invoice_id) AS purchase_frequency, SUM(il.quantity) AS total_purchase,SUM(i.total) AS total_amount_spent,
AVG(i.total) AS avg_order_value, DATEDIFF(MAX(i.invoice_date), MIN(i.invoice_date)) AS customer_tenure_days
from customer c
JOIN invoice i ON c.customer_id = i.customer_id
JOIN invoice_line il ON i.invoice_id = il.invoice_id
group by c.customer_id
),
Segment AS (
SELECT customer_id,purchase_frequency,total_purchase,total_amount_spent,avg_order_value,customer_tenure_days,
CASE
WHEN customer_tenure_days >= 365 THEN 'Long-Term'
ELSE 'New'
END AS customer_segment
from Purchase_status
)
select customer_segment, ROUND(AVG(purchase_frequency), 2) AS avg_purchase_frequency,ROUND(AVG(total_purchase), 2) AS avg_basket_size,
ROUND(AVG(total_amount_spent), 2) AS avg_spending_amount, ROUND(AVG(avg_order_value), 2) AS avg_order_value from Segment
group by customer_segment;

 -- 4.Product Affinity Analysis: Which music genres, artists, or albums are frequently purchased together by customers? 
--       How can this information guide product recommendations and cross-selling initiatives factors?  

-- Identify Frequently Purchased Together Products
-- -- 1. Genre Affinity Analysis --
WITH track_combinations AS (
SELECT il1.track_id AS track_id_1,il2.track_id AS track_id_2,COUNT(*) AS times_purchased_together
FROM invoice_line il1
JOIN invoice_line il2 ON il1.invoice_id = il2.invoice_id AND il1.track_id < il2.track_id
GROUP BY il1.track_id, il2.track_id
),
genre_combinations AS (
SELECT t1.genre_id AS genre_id_1,t2.genre_id AS genre_id_2, COUNT(*) AS times_purchased_together
FROM track_combinations tc
JOIN track t1 ON tc.track_id_1 = t1.track_id
JOIN track t2 ON tc.track_id_2 = t2.track_id
WHERE t1.genre_id <> t2.genre_id
GROUP BY t1.genre_id, t2.genre_id
)
SELECT g1.name AS genre_1, g2.name AS genre_2, gc.times_purchased_together
FROM genre_combinations gc
JOIN genre g1 ON gc.genre_id_1 = g1.genre_id
JOIN genre g2 ON gc.genre_id_2 = g2.genre_id
ORDER BY gc.times_purchased_together DESC;
-- -- Artist Affinity Analysis --
WITH track_combinations AS (
SELECT il1.track_id AS track_id_1, il2.track_id AS track_id_2, COUNT(*) AS times_purchased_together
FROM invoice_line il1
JOIN invoice_line il2 ON il1.invoice_id = il2.invoice_id AND il1.track_id < il2.track_id
GROUP BY il1.track_id, il2.track_id
),
artist_combinations AS (
SELECT a1.artist_id AS artist_id_1, a2.artist_id AS artist_id_2, COUNT(*) AS times_purchased_together
FROM track_combinations tc
JOIN track t1 ON tc.track_id_1 = t1.track_id
JOIN album al1 ON t1.album_id = al1.album_id
JOIN artist a1 ON al1.artist_id = a1.artist_id
JOIN track t2 ON tc.track_id_2 = t2.track_id
JOIN album al2 ON t2.album_id = al2.album_id
JOIN artist a2 ON al2.artist_id = a2.artist_id
WHERE a1.artist_id <> a2.artist_id
GROUP BY a1.artist_id, a2.artist_id
)
SELECT a1.name AS artist_1, a2.name AS artist_2, ac.times_purchased_together
FROM artist_combinations ac
JOIN artist a1 ON ac.artist_id_1 = a1.artist_id
JOIN artist a2 ON ac.artist_id_2 = a2.artist_id
ORDER BY ac.times_purchased_together DESC;
-- -- Album Affinity Analysis --
WITH track_combinations AS (
SELECT il1.track_id AS track_id_1, il2.track_id AS track_id_2, COUNT(*) AS times_purchased_together
FROM invoice_line il1
JOIN invoice_line il2 ON il1.invoice_id = il2.invoice_id AND il1.track_id < il2.track_id
GROUP BY il1.track_id, il2.track_id
),
album_combinations AS (
SELECT al1.album_id AS album_id_1, al2.album_id AS album_id_2, COUNT(*) AS times_purchased_together
FROM track_combinations tc
JOIN track t1 ON tc.track_id_1 = t1.track_id
JOIN album al1 ON t1.album_id = al1.album_id
JOIN track t2 ON tc.track_id_2 = t2.track_id
JOIN album al2 ON t2.album_id = al2.album_id
WHERE al1.album_id <> al2.album_id
GROUP BY al1.album_id, al2.album_id
)
SELECT al1.title AS album_1, al2.title AS album_2, ac.times_purchased_together
FROM album_combinations ac
JOIN album al1 ON ac.album_id_1 = al1.album_id
JOIN album al2 ON ac.album_id_2 = al2.album_id
ORDER BY ac.times_purchased_together DESC;

-- Product Affinity Based on Region
SELECT c.country,g.name AS Genre_Name, COUNT(il.track_id) AS TotalPurchases, SUM(il.unit_price * il.quantity) AS TotalRevenue
FROM invoice i
JOIN invoice_line il ON i.invoice_id = il.invoice_id
JOIN track t ON il.track_id = t.track_id
JOIN genre g ON t.genre_id = g.genre_id
JOIN customer c ON i.customer_id = c.customer_id
GROUP BY c.country, g.name
ORDER BY TotalRevenue DESC;

-- 5.	Regional Market Analysis: Do customer purchasing behaviors and churn rates vary across different geographic regions 
-- or store locations? How might these correlate with local demographic or economic factors.
use chinook;
-- - Churn Rate Calculation
WITH customer_purchases AS (
select c.customer_id,c.first_name,c.last_name,c.country,c.state,SUM(i.total) AS total_spent,COUNT(i.invoice_id) AS purchase_count
from customer c
JOIN invoice i ON c.customer_id = i.customer_id
group by c.customer_id, c.first_name, c.last_name, c.country, c.state
),
churn_customers AS (
select c.customer_id,c.first_name,c.last_name,c.country,c.state,MAX(i.invoice_date) AS last_purchase_date
from customer c
JOIN invoice i ON c.customer_id = i.customer_id
group by c.customer_id, c.first_name, c.last_name, c.country, c.state
having MAX(i.invoice_date) < DATE_SUB(CURDATE(), INTERVAL 1 YEAR)
)
select cp.country,COALESCE(cp.state,"Not Specified"),COUNT(DISTINCT cp.customer_id) AS customer_count,SUM(cp.total_spent) AS total_revenue,
ROUND(AVG(cp.total_spent),2) AS avg_spent_per_customer,ROUND(AVG(cp.purchase_count),2) AS avg_purchase_count,ROUND(COUNT(DISTINCT cc.customer_id),2) AS churned_customers,
ROUND((COUNT(DISTINCT cc.customer_id) / COUNT(DISTINCT cp.customer_id)) * 100,2) AS churn_rate
from customer_purchases cp
LEFT JOIN churn_customers cc ON cp.customer_id = cc.customer_id AND cp.state = cc.state
group by cp.country, cp.state
order by total_revenue DESC;

-- --6. Customer Risk Profiling: Based on customer profiles (age, gender, location, purchase history),
--  which customer segments are more likely to churn or pose a higher risk of reduced spending? What factors contribute to this risk?

-- Identify customers with declining purchase trends

WITH customer_purchase_history AS (
SELECT c.customer_id,c.first_name,c.last_name,c.country,c.state,YEAR(i.invoice_date) AS year,SUM(i.total) AS total_spent
FROM customer c
JOIN invoice i ON c.customer_id = i.customer_id
GROUP BY c.customer_id, c.first_name, c.last_name, c.country, c.state, YEAR(i.invoice_date)
),
-- Calculate the change in spending from year to year
yearly_spending_change AS (
SELECT cph.customer_id, CONCAT(cph.first_name, " ", cph.last_name)as customer_name, cph.country, cph.state, cph.year, cph.total_spent,
LAG(cph.total_spent) OVER (PARTITION BY cph.customer_id ORDER BY cph.year) AS previous_year_spent,
cph.total_spent - LAG(cph.total_spent) OVER (PARTITION BY cph.customer_id ORDER BY cph.year) AS spending_change
FROM customer_purchase_history cph
)

-- --Identify customers with a negative spending change (potential churn risk)
SELECT ysc.customer_id, ysc.customer_name, ysc.country, COALESCE(ysc.state,'Unknown'), ysc.year, ysc.total_spent, ysc.spending_change
FROM yearly_spending_change ysc
WHERE ysc.spending_change < 0 
ORDER BY ysc.spending_change ASC; 

-- 10.	How can you alter the "Albums" table to add a new column named "ReleaseYear" of type INTEGER to store the release year of each album?
      
       ALTER TABLE album
       add column ReleaseYear INT;
       
-- 11.	Chinook is interested in understanding the purchasing behavior of customers based on their geographical location. 
   -- They want to know the average total amount spent by customers from each country, 
-- along with the number of customers and the average number of tracks purchased per customer. Write an SQL query to provide this information.

with average_toatal_amount as(
select country,AVG(total_amount)as avg_amount,numberofcustomers from(
select c.country,sum(i.total)as total_amount,count(*)as numberofcustomers from invoice i
join customer c on c.customer_id=i.customer_id
group by c.country
)amount
group by country
),
avg_tracks as(
select customer_id,customer_name,avg(n_tracks)as average_number_of_tracks from(
select c.customer_id,CONCAT(c.first_name," ",c.last_name) as customer_name, c.country,count(t.track_id) as n_tracks from track t
join invoice_line il on il.track_id=t.track_id
join invoice i on i.invoice_id=il.invoice_id
join customer c on c.customer_id=i.customer_id
group by c.customer_id)track_count
group by customer_id,customer_name
order by average_number_of_tracks desc
)
select a.country,ROUND(a.avg_amount,2)AS Average_amount,a.numberofcustomers,ROUND(tr.average_number_of_tracks,2)as average_number_of_tracks 
from average_toatal_amount a,avg_tracks tr
order by Average_amount desc;












-- "Given two tables, customers and orders, where customers has columns:

-- id: integer

-- name: string

-- and orders has columns:

-- id: integer

-- customer_id: integer (foreign key referencing customers.id)

-- order_date: date

-- total_amount: decimal

-- Write a query to find customers who placed at least two orders in the last year."


 select  c.id,c.name from customers c
 JOIN orders o on o.customer_id=c.id
 where order_date between "01-01-2023" and "31-12-2023"
 group by c.id,c.name
 having count(o.id)>=2;
 
 
--  Write a query to pivot monthly sales data to show total sales for each month in separate columns. Assume you have a table sales(sale_id, sale_date, amount).

select YEAR,SUM(CASE WHEN MONTH(sale_date)='01' then amount else 0 end)as Jan_sales,
SUM(CASE WHEN MONTH(sale_date)='02' then amount else 0 end)as Feb_sales;



-- Write a recursive query to find all managers in the hierarchy of a given employee. 
-- Assume you have a table employees(employee_id, employee_name, manager_id).

select e.employee_id,m.employee_id as manager
from employee e
JOIN employee m on e.manager_id=m.employee_id


-- Given a table reviews with columns review_id, product_id, user_id, and rating, write a query to find products whose average
--  rating is greater than the average rating of all products reviewed by the same users.
select product_id from table t1
group by product_id
having avg(rating)> (select avg(rating)as avg_rating from table t
where t.user_id=t1.user_id);
